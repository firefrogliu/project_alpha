make
gnome-open biochip_arch_syn_final_v2.pdf
